#include"main.h"
void clear_log(unsigned char key)
{
    lap = 0;
    overflow = 0;
    char arr[10] = {};
    arr[0] = time[0];
    arr[1] = time[1];
    arr[2]= time[3];
    arr[3] = time[4];
    arr[4] = time[6];
    arr[5] = time[7];
    arr[6] = 'C';
    arr[7] = 'L';
    arr[8] = sp1;
    arr[9] = sp2;
    for(int j=0; j<10; j++)
    {
        write_ext_eeprom(lap*10+j,arr[j]);
    }
    lap++;
    clcd_print(" clear log    ", LINE1(0));
    clcd_print(" Successful     ", LINE2(0));
    for (unsigned long int m = 0; m < 300000; m++);
    CLEAR_DISP_SCREEN;
    main_f = 2;
}