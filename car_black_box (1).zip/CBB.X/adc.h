void init_adc(void);
unsigned short read_adc(unsigned char channel);
void write_eeprom(unsigned char data, unsigned char addr);
unsigned char read_eeprom(unsigned char addr);
