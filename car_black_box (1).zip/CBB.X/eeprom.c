#include "main.h"

// Function to read data from EEPROM at the specified address
unsigned char read_eeprom(unsigned char addr)
{
    // Set the EEPROM address register (EEADR) with the provided address
    EEADR = addr;

    // Set EEPGD to 0 for accessing data memory
    EEPGD = 0;

    // Set CFGS to 0 for accessing program memory
    CFGS = 0;

    // Disable write enable (WREN) to prevent accidental writes
    WREN = 0;

    // Set the Read Control bit (RD) to 1 to initiate the read operation
    RD = 1;

    // Return the data read from the specified EEPROM address
    return EEDATA;
}

// Function to write data to EEPROM at the specified address
void write_eeprom(unsigned char data, unsigned char addr) {
    // Clear the EEPROM write operation complete flag
    EEIF = 0;

    // Set the data to be written in the EEDATA register
    EEDATA = data;

    // Set the EEPROM address register (EEADR) with the provided address
    EEADR = addr;

    // Set EEPGD to 0 for accessing data memory
    EEPGD = 0;

    // Set CFGS to 0 for accessing program memory
    CFGS = 0;

    // Enable write enable (WREN) to allow EEPROM write operations
    WREN = 1;

    // Disable global interrupts to prevent interruption during EEPROM write
    GIE = 0;

    // Required sequence to initiate the EEPROM write operation
    EECON2 = 0X55;
    EECON2 = 0XAA;

    // Set the write control bit (WR) to 1 to initiate the write operation
    WR = 1;

    // Enable global interrupts
    GIE = 1;

    // Wait for the EEPROM write operation to complete
    while (!EEIF);
}
