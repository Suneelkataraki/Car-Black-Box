#include"main.h"

// Function to initialize the matrix keypad
void init_matrix_keypad(void) {
    // Configure PORTB as digital
    ADCON1 = 0x0F;

    // Set Rows (RB7 - RB5) as Outputs and Columns (RB4 - RB1) as Inputs
    TRISB = 0x1E;

    // Set PORTB input as pull-up for columns
    RBPU = 0;

    // Set initial state for Rows (RB7 - RB5) as HIGH
    MATRIX_KEYPAD_PORT = MATRIX_KEYPAD_PORT | 0xE0;
}

// Function to scan the matrix keypad and return the pressed key
unsigned char scan_key(void) {
    // Scan Row 1
    ROW1 = LO;
    ROW2 = HI;
    ROW3 = HI;

    // Check for a pressed key in the columns
    if (COL1 == LO) {
        return 1;
    } else if (COL2 == LO) {
        return 4;
    } else if (COL3 == LO) {
        return 7;
    } else if (COL4 == LO) {
        return 10;
    }

    // Scan Row 2
    ROW1 = HI;
    ROW2 = LO;
    ROW3 = HI;

    // Check for a pressed key in the columns
    if (COL1 == LO) {
        return 2;
    } else if (COL2 == LO) {
        return 5;
    } else if (COL3 == LO) {
        return 8;
    } else if (COL4 == LO) {
        return 11;
    }

    // Scan Row 3
    ROW1 = HI;
    ROW2 = HI;
    ROW3 = LO;
    ROW3 = LO;
    // Check for a pressed key in the columns
    if (COL1 == LO) {
        return 3;
    } else if (COL2 == LO) {
        return 6;
    } else if (COL3 == LO) {
        return 9;
    } else if (COL4 == LO) {
        return 12;
    }

    // Return 0xFF if no key is pressed
    return 0xFF;
}

// Function to read the matrix keypad switches
// Parameters:
//   - detection_type: STATE_CHANGE for detecting state changes, LEVEL_CHANGE for detecting level changes
unsigned char read_switches(unsigned char detection_type) {
    static unsigned char once = 1, key;

    // State Change Detection
    if (detection_type == STATE_CHANGE) {
        // Get the pressed key from scanning
        key = scan_key();

        // Check for a pressed key and state change
        if (key != 0xFF && once) {
            once = 0;
            return key;
        } else if (key == 0xFF) {
            once = 1;
        }
    }
    // Level Change Detection
    else if (detection_type == LEVEL_CHANGE) {
        // Return the pressed key without state change detection
        return scan_key();
    }

    // Return 0xFF if no key is pressed or for invalid detection type
    return 0xFF;
}
