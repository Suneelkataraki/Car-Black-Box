#include"main.h"
unsigned char lap1;
void download_log()
{
        init_uart();
    if(overflow == 0)
    {
    for(int l=0; l<lap; l++)
    {
                int k=0;

        for(int j=0; j<16; j++)
        {
            if(j == 0)
                putch( l+48);
            else if(j==4 || j==7)
            {
                putch(':');
            }
            else if(j==1 || j==10 || j==13)
            {
                putch(' ');
            }
            else
            {
                putch(read_ext_eeprom(l*10+k));
                k++;
            }
        }
        puts("\r\n");
    }
    }
    else if(overflow == 1)
    {
//        lap1 = lap;
    for(int l=0; l<10; l++)
    {
        int k=0;
        for(int j=0; j<16; j++)
        {
            if(j == 0)
                putch(l+48);
            else if(j==4 || j==7)
            {
                putch(':');
            }
            else if(j==10 || j==13 || j == 1)
            {
                putch(' ');
            }
            else
            {
                putch(read_ext_eeprom((lap+l)%10*10+k));
                k++;
            }
        }
        puts("\r\n");  
    }
    }
        clcd_print("  download_log  ",LINE1(0));
        clcd_print("successfully   ",LINE2(0));
        for(long int i = 300000; i--; );
        CLEAR_DISP_SCREEN;
        main_f=2;
}