#include"main.h"
void store_event()
{
    char arr[11] = {};
    arr[0] = time[0];
    arr[1] = time[1];
    arr[2]=  time[3];
    arr[3] = time[4];
    arr[4] = time[6];
    arr[5] = time[7];
    arr[6] = ev[i][0];
    arr[7] = ev[i][1];
    arr[8] = sp1;
    arr[9] = sp2;
    for(int j=0; j<10; j++)
    {
        write_ext_eeprom( lap*10+j,arr[j]);
    }
//      for(int j=0; j<10; j++)
//    {
//        clcd_putch(read_ext_eeprom(lap*10+j),LINE1(j));
//    }
    lap++;
    if(lap == 10)
    {
        lap = 0;
        overflow = 1;
    }
}