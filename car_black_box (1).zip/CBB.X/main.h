#include<xc.h>
#include <string.h>
#include "adc.h"
#include "clcd.h"
#include"matrix.h"
#include "ds1307.h"
#include "i2c.h"
#include "uart.h"
#include "ext_eeprom.h"
#define DASHBOARD               0
#define PASSWORD                1
#define MENU                    2
#define MENU_ENTER              3
#define VIEWLOG                 0
#define DOWNLOADLOG             1
#define CLEARLOG                2
#define SETTIME                 3
#define CHANGEPASS              4

void dashboard(unsigned char key);               
void password(unsigned char key);
void menu();
void view_log();
void download_log();
void clear_log(unsigned char key);
void settime();
void change_pass(unsigned char key);
void store_event();
void init_timer2();
unsigned char sp1,sp2, main_f = 0, menu_f = 0;
int lap= 0, overflow = 0, val, i =0, sec = 0,count1 = 0;
char ev[][3] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "_C", "DL", "CL", "ST", "CP"};