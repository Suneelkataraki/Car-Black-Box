#include"main.h"
// Interrupt Service Routine (ISR)
void __interrupt() isr() {

    // Check if Timer2 interrupt flag is set
    if (TMR2IF) {
        // Check if count has reached 20000
        if (count1++ == 20000) {
            // Reset count
            sec++;
            count1 = 0; 
        }
        // Clear Timer2 interrupt flag
        TMR2IF = 0; 
    }
}
