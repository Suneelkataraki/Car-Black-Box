#include"main.h"
unsigned int wait1 = 0;
unsigned char star_f = 0, m_ind = 0,pre_key;;
void menu()
{
    char menu[5][17] = {"view log       ", "download log   ", "clear log      ", "set time       ", "change password "};
    char k = read_switches(LEVEL_CHANGE);
     if(star_f == 0)
    {
        clcd_putch('*', LINE1(0));
        clcd_putch(' ', LINE2(0));
    }
    else
    {
        clcd_putch(' ', LINE1(0));
        clcd_putch('*', LINE2(0));
    }
 
    clcd_print(menu[m_ind], LINE1(1));
    clcd_print(menu[m_ind+1], LINE2(1));
    if(k != 0XFF)
    {
        pre_key = k;
        wait1++;
    if(wait1 > 300)
    {
        wait1 = 0;
        if(k == 11)
        {
        CLEAR_DISP_SCREEN;
        main_f = 3;
        menu_f = star_f + m_ind;
        if(menu_f == 0)
        {
            clcd_print("#log           ",LINE1(0));
        }
        else if(menu_f == 3)
        {
            clcd_print("HH:MM:SS       ",LINE1(0));
        }
        }
        else if(k == 12)
        {
            CLEAR_DISP_SCREEN;
            main_f = 0;
        }
    }
    }
    else if(wait1 >0 && wait1 < 300)
    {
        wait1 = 0;
        if(pre_key == 11)
        {
        if(star_f == 1)
          star_f = 0;
        else if(m_ind > 0)
            m_ind--;
        }
        else if(pre_key == 12)
        {
        if(star_f == 0)
          star_f = 1;
        else if(m_ind < 3)
            m_ind++;
        }
    }
    else
    {
        wait1 = 0;
    }
   
}