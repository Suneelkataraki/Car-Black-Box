#include"main.h"
unsigned int k = 0,l = 0,wait_c1=0, wait_c2 = 0;
unsigned char pass1[5], pass2[5];
void change_pass(unsigned char key)
{
    if(k == 0)
    {
        clcd_print(" Enter Password ", LINE1(0));
        clcd_print("                ", LINE2(0));
    }
    if (k < 4) {
    if (wait_c1++ <= 3000) {
        clcd_putch('_', LINE2(k));
    } else if (wait_c1++ <= 6000) {
        clcd_putch(' ', LINE2(k));
    } else {
        wait_c1 = 0;
    }
    if (key == 11 || key == 12) {
        clcd_putch('*', LINE2(k));
        pass1[k] = (key-11)+48;
        k++;
        for(int i = 1000;i--;);
    }
            
    if(k == 4){
            pass1[4] = '\0';
            clcd_print("Re Enter Password", LINE1(0));
            clcd_print("                ", LINE2(0));
    }
    }
    else if (l < 4) {
    if (wait_c2++ <= 3000) {
        clcd_putch('_', LINE2(l));
    } else if (wait_c2++ <= 6000) {
        clcd_putch(' ', LINE2(l));
    } else {
        wait_c2 = 0;
    }
    if (key == 11 || key == 12) {
        clcd_putch('*', LINE2(l));
        pass2[l] = (key-11)+48;
        l++;
        for(int i = 1000;i--;);
    }
            if(l == 4)
            {
            pass2[4] = '\0';
            }
    }
    else
    {
             if (strcmp(pass1, pass2) == 0) {
                // Display success message if the password is correct
                 for(int i=0; i<4; i++)
                     write_ext_eeprom(200+i, pass1[i]);
                    clcd_print(" change pass    ", LINE1(0));
                    clcd_print(" Successful     ", LINE2(0));
                    for (unsigned long int m = 0; m < 300000; m++);
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    k=0;l=0;
                    CLEAR_DISP_SCREEN;
                    main_f = 2;
             }
             else
             {
                    clcd_print(" change password ", LINE1(0));
                    clcd_print(" failed         ", LINE2(0));
                    for (unsigned long int m = 0; m < 300000; m++);
                    k=0;l=0;
                    CLEAR_DISP_SCREEN;
                    main_f = 2;
             }
    }
}