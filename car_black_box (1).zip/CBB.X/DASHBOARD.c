#include"main.h"
void dashboard(unsigned char key)
{
        clcd_print("  TIME   EV  SP", LINE1(0));
        clcd_print(time, LINE2(0));
        clcd_print(ev[i], LINE2(9));
        clcd_putch(sp1,LINE2(13));
        clcd_putch(sp2,LINE2(14));
        if(key == 2)
        {
            if(i == 7)
            {
                i = 2;
            }
            else if(i<6)
            {
            i++;
            }
            store_event();

        }
        else if(key == 3)
        {
            if(i == 7)
            {
                i = 2;
            }
            else if(i>2)
            {
                i--;
            }
            store_event();

        }
        else if(key == 1)
        {
            i=7;
            store_event();
        }
        else if(key == 11)
        {
          clcd_print(" Enter Password ", LINE1(0));
          main_f = 1;
          clcd_print("                ", LINE2(0));
        }
}