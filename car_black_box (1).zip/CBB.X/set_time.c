#include"main.h"
unsigned int wait3 = 0, t_flag = 1;
unsigned int hour, min, seconds, s_delay = 0;
void settime()
{
    static char mkp1,pre_k1,s_f=1;
    if(t_flag)
    {
     seconds = (time[6]-48)*10+(time[7]-48);
     min = (time[3]-48)*10+(time[4]-48);
     hour = (time[0]-48)*10+(time[1]-48);
     t_flag = 0;
    }
    mkp1 = read_switches(LEVEL_CHANGE);
    if(mkp1 != 0XFF)
    {
        pre_k1 = mkp1;
        wait3++;
        if(wait3 > 200)
        {
            wait3 = 0;
            if(mkp1 == 12)
            {
                write_ds1307(HOUR_ADDR,(hour/10)<<4|(hour%10));
                write_ds1307(MIN_ADDR,min);
                write_ds1307(SEC_ADDR,seconds);
                clcd_print("  set time     ",LINE1(0));
                clcd_print("successfully   ",LINE2(0));
                for(int k=300000; k--; );
                CLEAR_DISP_SCREEN;
                main_f = 2;
            }
            else if(mkp1 == 11)
            {
                CLEAR_DISP_SCREEN;
                main_f = 2;
            }
        }
    }
    else if(wait3 >0 && wait3 < 200)
    {
        wait3 = 0;
    if(pre_k1 == 11)
    {
       if(s_f == 3)
       {
           seconds++;
           if(seconds > 59)
               seconds = 0;
       }
       else if(s_f == 2)
       {
           min++;
           if(min > 59)
               min = 0;
       }
       else if(s_f == 1)
       {
           hour++;
           if(hour > 23)
               hour = 0;
       }
    }
    else if(pre_k1 == 12)
    {
        if(s_f == 1)
            s_f = 2;
        else if(s_f == 2)
            s_f = 3;
        else if(s_f == 3)
            s_f = 1;
    }
    }
    else
    {
        wait3 = 0;
    }
    if (s_delay++ < 100) {
    clcd_putch(hour/10+48, LINE2(0));
    clcd_putch(hour%10+48, LINE2(1));
    clcd_putch(':', LINE2(2));
    clcd_putch(min/10+48, LINE2(3));
    clcd_putch(min%10+48, LINE2(4));
    clcd_putch(':', LINE2(5));
    clcd_putch(seconds/10+48, LINE2(6));
    clcd_putch(seconds%10+48, LINE2(7));
    }
     else if (s_delay < 200) {
         if(s_f == 1)
         {
             clcd_print("  ", LINE2(0));
         }
         else if(s_f == 2)
         {
             clcd_print("  ", LINE2(3));
         }
         else if(s_f == 3)
         {
             clcd_print("  ", LINE2(6));
         }
    } 
    else
        s_delay = 0;
}
   
           