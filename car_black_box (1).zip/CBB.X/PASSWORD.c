#include"main.h"
char str[5];
char pass[5];
unsigned char attempt = 3, flag =1;
unsigned int j = 0, wait = 5500, counter=120, delay = 0;
void password(unsigned char key)
{
    if(flag)
        delay++;
    if(key == 0XFF && delay == 4000)
    {
        j=0;
        main_f = 0;
    }
            // Loop to collect password input
            if (j < 4) {
              // Display underscores during the first part of the entry
    if (wait++ <= 3000) {
        clcd_putch('_', LINE2(j));
    } else if (wait++ <= 6000) {
        clcd_putch(' ', LINE2(j));
    } else {
        wait = 0;
    }
    if (key == 11 || key == 12) {
        clcd_putch('*', LINE2(j));
        pass[j] = (key-11)+48;
        j++;
        delay = 0;
        for(int i = 1000;i--;);
    }
            }
            pass[4] = '\0';
        // Check password and take appropriate action
        if (j == 4) {
            // Check if the entered password matches the stored password
            for(int i=0; i<4; i++)
                str[i] = read_ext_eeprom(200+i);
            str[4] = '\0';
            if (strcmp(str, pass) == 0) {
                // Display success message if the password is correct
                    clcd_print(" Enter password ", LINE1(0));
                    clcd_print(" Successfully ", LINE2(0));
                    for (unsigned long int k = 0; k < 300000; k++);
                    CLEAR_DISP_SCREEN;
                    main_f = 2;
                    j=0;attempt=3;
                
            } else {
                // Handle incorrect password attempts
                if (attempt != 1) {
                    // Decrement the remaining attempts count
                    attempt--;

                    // Display remaining attempts and prompt for a new password
                    clcd_putch(attempt + 48, LINE1(0));
                    clcd_print("  attempts     ", LINE1(1));
                    clcd_print("remaining       ", LINE2(0));

                    // Delay for a short period
                    for (unsigned long int l = 0; l < 300000; l++);
                    
                    // Display the prompt for a new password
                    clcd_print(" Enter Password ", LINE1(0));
                    clcd_print("                ", LINE2(0));

                    // Reset variables for the next password attempt
                    j = 0;
                } else {
                    init_timer2();
                    flag = 0;
                    if(sec)
                    {
                        clcd_print("you are blocked", LINE1(1));
                        clcd_print(" for     seconds", LINE2(0));
                        clcd_putch(counter/100+48, LINE2(5)); 
                        clcd_putch(counter/10%10+48, LINE2(6)); 
                        clcd_putch(counter%10+48, LINE2(7));
                        counter--;
                        sec = 0;
                    }
                   if(counter == 0)
                   {
                        j=0;
                        attempt = 3;
                        counter = 120;flag = 1;
                        GIE = 0; PEIE = 0; TMR2IE = 0;
                        clcd_print(" Enter Password ", LINE1(0));
                        clcd_print("                ", LINE2(0));
                   }
                }
            }
        }
}