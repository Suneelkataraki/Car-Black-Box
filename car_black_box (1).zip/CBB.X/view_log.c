#include"main.h"
unsigned int s_i = 0, a_i = 0;
unsigned int wait2 = 0;
void view_log()
{
   // s_i = lap;
    static char mkp,pre_k; 
    mkp = read_switches(LEVEL_CHANGE); 

    if(mkp != 0XFF)
    {
        pre_k = mkp;
        wait2++;
        if(wait2 > 200)
        {
            wait2 = 0;
            if(mkp == 12)
            {
                CLEAR_DISP_SCREEN;
                main_f = 2;
            }
        }
    }
    else if(wait2 >0 && wait2 < 200)
    {
        wait2 = 0;
    if(pre_k == 11)
    {
        if(overflow==0)
        {
            s_i = 0;
        if(a_i < lap-1)
            a_i++;
        }
        else 
        {
            s_i = lap;
            if(a_i<9)
                a_i++;
        }
    }
    else if(pre_k == 12)
        if(a_i > 0)
            a_i--; 
    }
    else
    {
        wait2 = 0;
    }
    clcd_putch(a_i+48,LINE2(0));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10*10), LINE2(2));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 + 0X01), LINE2(3));
    clcd_putch(':', LINE2(4));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X02), LINE2(5));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X03), LINE2(6));
    clcd_putch(':', LINE2(7));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X04), LINE2(8));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X05), LINE2(9));
    clcd_putch(' ', LINE2(10));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X06), LINE2(11));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X07), LINE2(12));
    clcd_putch(' ', LINE2(13));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 +0X08), LINE2(14));
    clcd_putch(read_ext_eeprom((a_i+s_i)%10 * 10 + 0X09), LINE2(15));
}