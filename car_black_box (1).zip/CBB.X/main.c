/*
name:suneel kataraki
date:28 december 2023
project:car_black_box
*/
#include "main.h"
void init_timer2() {
    // Enable global interrupts
    GIE = 1;

    // Enable peripheral interrupts
    PEIE = 1;

    // TIMER2 Configuration
    TMR2ON = 1;     // Turn on Timer2
    PR2 = 249;      // Set period register for Timer2
    TMR2IF = 0;     // Clear Timer2 interrupt flag
    TMR2IE = 1;     // Enable Timer2 interrupt
}
static void init_config(void)
{
    ADCON1 = 0X0F;
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_i2c();
	init_ds1307();
}

void main(void)
{
    init_config();
    char key;
    while (1)
    { 
        val = read_adc(4)/10.33;
        sp2 = val%10+48;
        sp1 = val/10+48;
        get_time();
        if(main_f == DASHBOARD)
        {
            key = read_switches(STATE_CHANGE);
            dashboard(key);
        }
        else if(main_f == PASSWORD)
        {
            key = read_switches(STATE_CHANGE);
            password(key);
        }
        else if(main_f == MENU)
        {
            menu();
        }
        else if(main_f == MENU_ENTER)
        {
            if(menu_f == VIEWLOG)
            {
                view_log();
            }
            else if(menu_f == DOWNLOADLOG)
            {
                download_log();
            }
            else if(menu_f == CLEARLOG)
            {
                clear_log(key);
            }
            else if(menu_f == SETTIME)
            {
             
                settime();
            }
            else if(menu_f == CHANGEPASS)
            {
                key = read_switches(STATE_CHANGE);
                change_pass(key);
            }
        }
    }
}